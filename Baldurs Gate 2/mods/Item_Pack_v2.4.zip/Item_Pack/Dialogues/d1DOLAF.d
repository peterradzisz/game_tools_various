// Dola Fadoon's dialogue in the Pocket Plane

BEGIN ~d1DOLAF~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN DolaFa01
  SAY @2000 // Greetings, mortal. My name is Dola Fadoon. I recognize you as the drow who freed my physical form from that accursed prison. As a token of thanks, I've come to offer you my help.
  IF ~~ THEN REPLY @2001 GOTO DolaFa02 // What kind of help, exactly?
  IF ~~ THEN REPLY @2004 GOTO DolaFa06 // You misunderstood me, I had no desire to set you free. I just wanted to kill you. I guess I'll have to try again.
END

IF ~~ THEN BEGIN DolaFa02
  SAY @2005 // This djinn is no match for your power, mortal. I would be of little help in the way of combat. I've come here to offer you my services as trader.
  = @2006 // I imagine you'll need gold in your crusade, and have many a magical item waiting to be disposed of. I can offer you a fair price for them here, saving you the hassle of travelling to the nearest available store, human or otherwise.
  IF ~~ THEN REPLY @2007 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // That does sound convenient. Very well, Dola Faloon, let me see what you have.
  IF ~~ THEN REPLY @2002 GOTO DolaFa03 // You said you recognized me?
  IF ~~ THEN REPLY @2003 GOTO DolaFa05 // Wait, how did you manage to come here?
  IF ~~ THEN REPLY @2010 GOTO DolaFa04 // Thank you, Dola Faloon, but your help is not needed. You can return to your home plane if you want.
  IF ~~ THEN REPLY @2004 GOTO DolaFa06 // You misunderstood me, I had no desire to set you free. I just wanted to kill you. I guess I'll have to try again.
END

IF ~~ THEN BEGIN DolaFa03
  SAY @2008 // Once I was no longer bound to that physical form, I was able to discern the nature of my killer. Such is one my abilities as an Air spirit.
  = @2009 // Well, mortal, what say you to my offer? Would you like me to supply you with gold in exchange for the trinkets you don't need?
  IF ~~ THEN REPLY @2003 GOTO DolaFa05 // Wait, how did you manage to come here?
  IF ~~ THEN REPLY @2010 GOTO DolaFa04 // Thank you, Dola Faloon, but your help is not needed. You can return to your home plane if you want.
  IF ~~ THEN REPLY @2007 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // // That does sound convenient. Very well, Dola Faloon, let me see what you have.
  IF ~~ THEN REPLY @2004 GOTO DolaFa06 // You misunderstood me, I had no desire to set you free. I just wanted to kill you. I guess I'll have to try again.
END

IF ~~ THEN BEGIN DolaFa04
  SAY @2012  // Very well, mortal. I wish you luck.
  IF ~~ THEN DO ~PlaySound("EFF_M01") CreateVisualEffectObject("SPPLANAR",Myself) Wait(1) PlaySound("EFF_M38") DestroySelf()~ EXIT
END

IF ~~ THEN BEGIN DolaFa05
  SAY @2011 // I hail from the Elemental Plane of Air, mortal, I am no stranger to planar travel. Although this pocket plane of yours is something I hadn't seen before, not amidst this chaos plane.
  = @2009 // Well, mortal, what say you to my offer? Would you like me to supply you with gold in exchange for the trinkets you don't need?
  IF ~~ THEN REPLY @2002 GOTO DolaFa03 // You said you recognized me?
  IF ~~ THEN REPLY @2010 GOTO DolaFa04 // Thank you, Dola Faloon, but your help is not needed. You can return to your home plane if you want.
  IF ~~ THEN REPLY @2007 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // // That does sound convenient. Very well, Dola Faloon, let me see what you have.
  IF ~~ THEN REPLY @2004 GOTO DolaFa06 // You misunderstood me, I had no desire to set you free. I just wanted to kill you. I guess I'll have to try again.
END

IF ~~ THEN BEGIN DolaFa06
  SAY @2013  // Once is enough, mortal. Gone I am from this plane.
  IF ~~ THEN DO ~PlaySound("EFF_M01") CreateVisualEffectObject("SPPLANAR",Myself) Wait(1) PlaySound("EFF_M38") DestroySelf()~ EXIT
END

IF ~NumTimesTalkedToGT(0)~ THEN BEGIN DolaFa07
  SAY @2014 // Greetings again, potent one. Have you got any more items you wish to bargain?
  IF ~Global("HadBhaal25Dream1","GLOBAL",0)~ THEN REPLY @1502 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~Global("HadBhaal25Dream1","GLOBAL",1)
      Global("d1DolaSignatureItem","GLOBAL",0)~ THEN REPLY @1502 GOTO DolaFa08 // Yes. Show me what you have.
  IF ~Global("HadBhaal25Dream1","GLOBAL",1)
      Global("d1DolaSignatureItem","GLOBAL",1)~ THEN REPLY @1502 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~Global("HadBhaal25Dream1","GLOBAL",1)
      Global("d1DolaSignatureItem","GLOBAL",2)~ THEN REPLY @1502 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~Global("d1DolaSignatureItem","GLOBAL",1)~ THEN REPLY @2022 GOTO DolaFa11 // Actually, I was wondering if you could help me in another way other than as a merchant.
  IF ~Global("d1DolaSignatureItem","GLOBAL",2)~ THEN REPLY @2030 GOTO DolaFa15 // Do I have anything you could duplicate?
  IF ~Global("d1DolaSignatureItem","GLOBAL",3)~ THEN REPLY @1502 DO ~StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~~ THEN REPLY @1503 EXIT // Not at the moment.
END

IF ~~ THEN BEGIN DolaFa08
  SAY @2015 // If I may, you look a bit apprehensive, potent one. How goes your crusade?
  IF ~~ THEN REPLY @2016 GOTO DolaFa09 // It goes, if barely.
  IF ~~ THEN REPLY @2017 GOTO DolaFa09 // Bloody as always, thankfully.
  IF ~~ THEN REPLY @2018 GOTO DolaFa10 // Not well.
  IF ~~ THEN REPLY @2019 GOTO DolaFa10 // So far, it's advancing, but it's a long and tiring endeavor.
END

IF ~~ THEN BEGIN DolaFa09
  SAY @2020 // I am happy to hear so, mortal. Care to do business?~
  IF ~~ THEN REPLY @1502 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",1)
                             StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~~ THEN REPLY @1503 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",1)~ EXIT // Not at the moment.
  IF ~~ THEN REPLY @2022 GOTO DolaFa11 // Actually, I was wondering if you could help me in another way other than as a merchant.
END

IF ~~ THEN BEGIN DolaFa10
  SAY @2021 // I am saddened to hear so, mortal. Care to do business?
  IF ~~ THEN REPLY @1502 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",1)
                             StartStore("d1DolaF",LastTalkedToBy)~ EXIT // Yes. Show me what you have.
  IF ~~ THEN REPLY @1503 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",1)~ EXIT // Not at the moment.
  IF ~~ THEN REPLY @2022 GOTO DolaFa11 // Actually, I was wondering if you could help me in another way other than as a merchant.
END

IF ~~ THEN BEGIN DolaFa11
  SAY @2023 // Help you? In which way, potent one?
  IF ~~ THEN REPLY @2024 GOTO DolaFa13 // I don't know. What CAN you do to help?~
  IF ~~ THEN REPLY @2025 GOTO DolaFa12 // How about granting me a Wish or two?
END

IF ~~ THEN BEGIN DolaFa12
  SAY @2026 // Would that I could, but it is not within my power.
  IF ~~ THEN REPLY @2027 GOTO DolaFa13 // What CAN you do, then?~
END

IF ~~ THEN BEGIN DolaFa13
  SAY @2028 // Hmm. I might be able to gift you with a duplicate item of your choice. But the item should be unique, of the utmost quality, and it could only be done once.
  IF ~~ THEN REPLY @2029 GOTO DolaFa14 // Why didn't you tell me of this before?
  IF ~~ THEN REPLY @2030 GOTO DolaFa15 // Do I have anything you could duplicate?
  IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa14
  SAY @2032 // Because you just asked, and it only ocurred to me now. And because you've managed to come very far on your own, potent one.
  IF ~~ THEN REPLY @2030 GOTO DolaFa15 // Do I have anything you could duplicate?
  IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa15
  SAY @2033 // Let me see...
  IF ~PartyHasItem("COMPON02")~ THEN GOTO DolaFa16
  IF ~PartyHasItem("COMPON10")~ THEN GOTO DolaFa17
  IF ~PartyHasItem("COMPON15")~ THEN GOTO DolaFa18
  IF ~PartyHasItem("COMPON02")
      PartyHasItem("COMPON10")
      PartyHasItem("COMPON15")~ THEN GOTO DolaFa19
  IF ~!PartyHasItem("COMPON02")
      !PartyHasItem("COMPON10")
      !PartyHasItem("COMPON15")~ THEN GOTO DolaFa20
  IF ~PartyHasItem("COMPON02")
      PartyHasItem("COMPON10")
      !PartyHasItem("COMPON15")~ THEN GOTO DolaFa21
  IF ~PartyHasItem("COMPON02")
      PartyHasItem("COMPON15")
      !PartyHasItem("COMPON10")~ THEN GOTO DolaFa22
  IF ~PartyHasItem("COMPON10")
      PartyHasItem("COMPON15")
      !PartyHasItem("COMPON02")~ THEN GOTO DolaFa23
END

IF ~~ THEN BEGIN DolaFa16
  SAY @2034 // I could make you a copy of the Eye of Tyr.
    IF ~~ THEN REPLY #66664 DO ~GiveItemCreate("COMPON02",Player1,0,0,0)
                                SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                                CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT
    IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa17
  SAY @2035 // I could make you a copy of the Bowstring of Gond.
    IF ~~ THEN REPLY #66664 DO ~GiveItemCreate("COMPON10",Player1,0,0,0)
                                SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                                CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT
    IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa18
  SAY @2036 // I could make you a copy of the Heart of the Damned.
    IF ~~ THEN REPLY #66664 DO ~GiveItemCreate("COMPON15",Player1,0,0,0)
                                SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                                CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT
    IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa19
  SAY @2037 // I could make you a copy of either the Eye of Tyr, the Bowstring of Gond, or the Heart of the Damned.
    IF ~~ THEN REPLY @2038 DO ~GiveItemCreate("COMPON02",Player1,0,0,0)
                               SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                               CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Eye of Tyr.
    IF ~~ THEN REPLY @2039 DO ~GiveItemCreate("COMPON10",Player1,0,0,0)
                               SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                               CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Bowstring of Gond.
    IF ~~ THEN REPLY @2040 DO ~GiveItemCreate("COMPON15",Player1,0,0,0)
                               SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                               CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Heart of the Damned.
    IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa20
  SAY @2041 // I'm sorry, I don't see anything I can use.
  IF ~~ THEN DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN DolaFa21
  SAY @2042 // I could make you a copy of the Eye of Tyr or the Bowstring of Gond.
    IF ~~ THEN REPLY @2038 DO ~GiveItemCreate("COMPON02",Player1,0,0,0)
                               SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                               CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Eye of Tyr.
    IF ~~ THEN REPLY @2039 DO ~GiveItemCreate("COMPON10",Player1,0,0,0)
                               SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                               CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Bowstring of Gond.
    IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa22
  SAY @2043 // I could make you a copy of the Eye of Tyr or the Heart of the Damned.
  IF ~~ THEN REPLY @2038 DO ~GiveItemCreate("COMPON02",Player1,0,0,0)
                             SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                             CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Eye of Tyr.
  IF ~~ THEN REPLY @2040 DO ~GiveItemCreate("COMPON15",Player1,0,0,0)
                             SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                             CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Heart of the Damned.
  IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END

IF ~~ THEN BEGIN DolaFa23
  SAY @2044 // I could make you a copy of the Bowstring of Gond or the Heart of the Damned.
  IF ~~ THEN REPLY @2039 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                             GiveItemCreate("COMPON10",Player1,0,0,0)
                             CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Bowstring of Gond.
  IF ~~ THEN REPLY @2040 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",3)
                             GiveItemCreate("COMPON15",Player1,0,0,0)
                             CreateVisualEffect("spcrtwpn",[2300.1215])~ EXIT // Make me a copy of the Heart of the Damned.
  IF ~~ THEN REPLY @2031 DO ~SetGlobal("d1DolaSignatureItem","GLOBAL",2)~ EXIT // On second thought, just forget it.
END