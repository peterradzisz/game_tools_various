// Cromwell's Belm +2 Upgrade

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("SW1H30")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1563
                             = @1564
    IF ~!PartyHasItem("MISC43")~ THEN GOTO D1UPG01
    IF ~PartyHasItem("MISC43")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1565
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1566
    IF ~PartyGoldLT(15000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(14999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",5)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(15000)
                                                 TakePartyItemNum("SW1H30",1)
                                                 DestroyItem("SW1H30")
                                                 TakePartyItemNum("MISC43",1)
                                                 DestroyItem("MISC43")
                                                 DestroyGold(15000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END