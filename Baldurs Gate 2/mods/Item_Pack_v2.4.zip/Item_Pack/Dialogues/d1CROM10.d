// Cromwell's Reflection Shield +3 Forge

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("SHLD24")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1579
    IF ~OR(2)
          !NumItemsPartyGT("SCRL1N",1)
          !PartyHasItem("MISC41")~ THEN GOTO D1UPG01
    IF ~NumItemsPartyGT("SCRL1N",1)
        PartyHasItem("MISC41")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1580
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1581
    IF ~PartyGoldLT(5000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(4999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",10)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(5000)
                                                 TakePartyItemNum("SHLD24",1)
                                                 DestroyItem("SHLD24")
                                                 TakePartyItemNum("SCRL1N",2)
                                                 DestroyItem("SCRL1N")
                                                 TakePartyItemNum("MISC41",1)
                                                 DestroyItem("MISC41")
                                                 DestroyGold(5000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END