// Cromwell's Adjatha the Drinker +2 Upgrade

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("SW1H35")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1570
    IF ~!NumItemsPartyGT("MISC20",1)~ THEN GOTO D1UPG01
    IF ~NumItemsPartyGT("MISC20",1)~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1571
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1572
    IF ~PartyGoldLT(7500)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(7499)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",7)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(7500)
                                                 TakePartyItemNum("SW1H35",1)
                                                 DestroyItem("SW1H35")
                                                 TakePartyItemNum("MISC20",2)
                                                 DestroyItem("DAGG16")
                                                 DestroyGold(7500)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END