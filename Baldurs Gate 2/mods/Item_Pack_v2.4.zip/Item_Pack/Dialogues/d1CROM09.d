// Cromwell's Mauler's Arm +4 Forge

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("BLUN19")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1576
    IF ~OR(2)
          !PartyHasItem("POTN03")
          !PartyHasItem("MISC44")~ THEN GOTO D1UPG01
    IF ~PartyHasItem("POTN03")
        PartyHasItem("MISC44")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1577
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1578
    IF ~PartyGoldLT(15000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(14999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",9)
                                                  SetGlobal("ForgeStuff","GLOBAL",1)
                                                  TakePartyGold(15000)
                                                  TakePartyItemNum("BLUN19",1)
                                                  DestroyItem("BLUN19")
                                                  TakePartyItemNum("POTN03",1)
                                                  DestroyItem("POTN03")
                                                  TakePartyItemNum("MISC44",1)
                                                  DestroyItem("MISC44")
                                                  DestroyGold(15000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END