// Cromwell's Cloak of Protection +1 Upgrade

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("CLCK01")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1554
    IF ~OR(2)
          !NumItemsPartyGT("CLCK01",1)
          !PartyHasItem("MISC45")~ THEN GOTO D1UPG01
    IF ~NumItemsPartyGT("CLCK01",1)
        PartyHasItem("MISC45")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1555
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1556
    IF ~PartyGoldLT(5000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(4999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",2)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(5000)
                                                 TakePartyItemNum("CLCK01",2)
                                                 DestroyItem("CLCK01")
                                                 TakePartyItemNum("MISC45",1)
                                                 DestroyItem("MISC45")
                                                 DestroyGold(5000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END