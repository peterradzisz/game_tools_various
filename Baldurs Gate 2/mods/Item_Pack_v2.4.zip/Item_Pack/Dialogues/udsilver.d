// Replace Necaradan's Crossbow with Heaven and Earth as Adalon's reward

REPLACE_ACTION_TEXT ~udsilver~ ~GiveItemCreate("xbow10",LastTalkedToBy,1,1,1)~ ~GiveItemCreate("d1blun02",LastTalkedToBy,1,1,1)~