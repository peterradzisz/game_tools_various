// Cromwell's Reflection Shield +3 Forge

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("WA2DAK")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1582
    IF ~!PartyHasItem("SCRL5P")~ THEN GOTO D1UPG01
    IF ~PartyHasItem("SCRL5P")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1583
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1584
    IF ~PartyGoldLT(20000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(19999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",11)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(20000)
                                                 TakePartyItemNum("WA2DAK",1)
                                                 DestroyItem("WA2DAK")
                                                 TakePartyItemNum("SCRL5P",1)
                                                 DestroyItem("SCRL5P")
                                                 DestroyGold(20000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END