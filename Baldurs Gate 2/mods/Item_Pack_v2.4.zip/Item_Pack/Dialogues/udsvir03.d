// Replace Skullcrusher +3 with Badge of the Svirfneblin as Goldander Blackenrock's reward

REPLACE_ACTION_TEXT ~udsvir03~ ~GiveItemCreate("blun18",LastTalkedToBy,1,1,1)~ ~GiveItemCreate("d1amul05",LastTalkedToBy,1,1,1)~