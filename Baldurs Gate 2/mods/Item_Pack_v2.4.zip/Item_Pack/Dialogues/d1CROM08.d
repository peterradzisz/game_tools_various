// Cromwell's Periapt of Proof Against Poison Forge

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("AMUL14")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1573
    IF ~!NumItemsPartyGT("MISC23",2)~ THEN GOTO D1UPG01
    IF ~NumItemsPartyGT("MISC23",2)~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1574
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1575
    IF ~PartyGoldLT(5000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(4999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",8)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(5000)
                                                 TakePartyItemNum("AMUL14",1)
                                                 DestroyItem("AMUL14")
                                                 TakePartyItemNum("MISC23",3)
                                                 DestroyItem("MISC23")
                                                 DestroyGold(5000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END