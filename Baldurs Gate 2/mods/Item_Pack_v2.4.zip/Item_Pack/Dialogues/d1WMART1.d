// Small dialogue for Joluv in Amkethran

BEGIN ~D1WMART1~

IF ~True()~ THEN BEGIN d1Joluv
  SAY @1500
  = @1501
  IF ~~ THEN REPLY @1502   DO ~StartStore("wmart1",LastTalkedToBy)~ EXIT
  IF ~~ THEN REPLY @1503   EXIT
END