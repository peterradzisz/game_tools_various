// Cromwell's Ilbratha +1 Upgrade

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("SW1H26")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1560
    IF ~OR(2)
          !PartyHasItem("SCRL96")
          !PartyHasItem("MISC44")~ THEN GOTO D1UPG01
    IF ~PartyHasItem("SCRL96")
        PartyHasItem("MISC44")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1561
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1562
    IF ~PartyGoldLT(7500)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(7499)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",4)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(7500)
                                                 TakePartyItemNum("SW1H26",1)
                                                 DestroyItem("SW1H26")
                                                 TakePartyItemNum("SCRL96",1)
                                                 DestroyItem("SCRL96")
                                                 TakePartyItemNum("MISC44",1)
                                                 DestroyItem("MISC44")
                                                 DestroyGold(7500)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END