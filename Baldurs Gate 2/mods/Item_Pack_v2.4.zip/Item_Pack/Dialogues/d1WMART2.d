// Small dialogue for Deirdre in Amkethran

BEGIN ~D1WMART2~

IF ~True()~ THEN BEGIN d1Deirdre
  SAY @1504
  = @1505
  IF ~~ THEN REPLY @1502   DO ~StartStore("wmart2",LastTalkedToBy)~ EXIT
  IF ~~ THEN REPLY @1503   EXIT
END
