// Cromwell's Ring of Protection +1 Upgrade

EXTEND_BOTTOM WSMITH01 13
  IF ~PartyHasItem("RING06")~ THEN GOTO D1UPG00
END

APPEND WSMITH01
  IF ~~ THEN BEGIN D1UPG00 SAY @1550
    IF ~OR(2)
          !NumItemsPartyGT("RING06",1)
          !PartyHasItem("MISC42")~ THEN GOTO D1UPG01
    IF ~NumItemsPartyGT("RING06",1)
        PartyHasItem("MISC42")~ THEN GOTO D1UPG02
  END

  IF ~~ THEN BEGIN D1UPG01 SAY @1551
    IF ~~ THEN GOTO D1NOTNX
  END

  IF ~~ THEN BEGIN D1UPG02 SAY @1552
    IF ~PartyGoldLT(5000)~ THEN REPLY #66662 GOTO D1NOTNX
    IF ~PartyGoldGT(4999)~ THEN REPLY #66664 DO ~SetGlobal("D1Items","AR0334",1)
                                                 SetGlobal("ForgeStuff","GLOBAL",1)
                                                 TakePartyGold(5000)
                                                 TakePartyItemNum("RING06",2)
                                                 DestroyItem("RING06")
                                                 TakePartyItemNum("MISC42",1)
                                                 DestroyItem("MISC42")
                                                 DestroyGold(5000)~ GOTO 56
    IF ~~ THEN REPLY #66770 GOTO D1NOTNX
  END

  IF WEIGHT #-1 ~GlobalGT("D1Craft","AR0334",0)~ THEN BEGIN D1Craft SAY #59797
    IF ~~ THEN DO ~SetGlobal("D1Craft","AR0334",0)~ EXIT
  END

  IF ~~ THEN BEGIN D1NOTNX SAY @1553
   COPY_TRANS WSMITH01 13
  END
END